# My First Portfolio - Created with HTML, CSS, and Javascript

This is my first portfolio, built using HTML, CSS, and Javascript. I've used Javascript DOM to generate cards and elements that can be dynamically reused.

Feel free to clone this repository and customize it to your liking.

You can also check out the live repository [here](https://itssofi.dev/).

Don't forget to give this repository a star ⭐ if you find it helpful.

## License

This project is licensed under the MIT License.

---

[Visit my website](https://itssofi.dev/)

![image](https://github.com/SofiDevO/SofiDev-landingpage/assets/102200061/132c1833-def1-47ab-8a8d-13c5c0499257)
![image](https://github.com/SofiDevO/SofiDev-landingpage/assets/102200061/448f27ea-1efc-4608-a439-2e81cae00fc4)

![image](https://github.com/SofiDevO/SofiDev-landingpage/assets/102200061/fcd22a9d-5ff7-4673-a2a6-f51b65e4c213)
![image](https://github.com/SofiDevO/SofiDev-landingpage/assets/102200061/e0ed8666-e6f2-40be-a538-82bd019aa3d0)
